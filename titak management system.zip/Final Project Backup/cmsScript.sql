SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL';

CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci ;
CREATE SCHEMA IF NOT EXISTS `cms` DEFAULT CHARACTER SET latin1 ;
USE `mydb` ;
USE `cms` ;

-- -----------------------------------------------------
-- Table `cms`.`bill`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `cms`.`bill` (
  `id` INT(11) NOT NULL ,
  `name` VARCHAR(200) NULL DEFAULT NULL ,
  `mobileNumber` VARCHAR(30) NULL DEFAULT NULL ,
  `email` VARCHAR(200) NULL DEFAULT NULL ,
  `date` VARCHAR(50) NULL DEFAULT NULL ,
  `total` VARCHAR(200) NULL DEFAULT NULL ,
  `createdBy` VARCHAR(200) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `cms`.`category`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `cms`.`category` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(200) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
AUTO_INCREMENT = 12
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `cms`.`product`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `cms`.`product` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(200) NULL DEFAULT NULL ,
  `category` VARCHAR(200) NULL DEFAULT NULL ,
  `price` VARCHAR(200) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) )
ENGINE = InnoDB
AUTO_INCREMENT = 7
DEFAULT CHARACTER SET = latin1;


-- -----------------------------------------------------
-- Table `cms`.`user`
-- -----------------------------------------------------
CREATE  TABLE IF NOT EXISTS `cms`.`user` (
  `id` INT(11) NOT NULL AUTO_INCREMENT ,
  `name` VARCHAR(200) NULL DEFAULT NULL ,
  `email` VARCHAR(200) NULL DEFAULT NULL ,
  `mobileNumber` VARCHAR(10) NULL DEFAULT NULL ,
  `address` VARCHAR(200) NULL DEFAULT NULL ,
  `password` VARCHAR(200) NULL DEFAULT NULL ,
  `securityQuestion` VARCHAR(200) NULL DEFAULT NULL ,
  `answer` VARCHAR(200) NULL DEFAULT NULL ,
  `status` VARCHAR(20) NULL DEFAULT NULL ,
  PRIMARY KEY (`id`) ,
  UNIQUE INDEX `email` (`email` ASC) )
ENGINE = InnoDB
AUTO_INCREMENT = 9
DEFAULT CHARACTER SET = latin1;



SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import javax.swing.JOptionPane;

/**
 *
 * @author Ehsan Paiman
 */
public class tables {
    public static void main(String args[]){
        try{
           // String userTable = "create table user(id int AUTO_INCREMENT PRIMARY KEY, name VARCHAR(200), email VARCHAR(200), mobileNumber VARCHAR(10), address VARCHAR(200), password VARCHAR(200), securityQuestion VARCHAR(200), answer VARCHAR(200), status VARCHAR(20), UNIQUE (email))";
          //  String adminDetails = "insert into user(name,email,mobileNumber,address,password,securityQuestion,answer,status) values('admin','Hamid@gmail.com','1234567890','Kabul','admin','what is your teacher name','ABC','true')";
          //  String categoryTable = "create table category(id int AUTO_INCREMENT primary key, name varchar(200))";
         //   String productTable = "create table product(id int AUTO_INCREMENT PRIMARY KEY, name VARCHAR(200), category VARCHAR(200), price VARCHAR(200))";
            String billTable= "Create table bill(id int Primary Key,name varchar(200),mobileNumber varchar(30),email varchar(200), date varchar(50), total varchar(200), createdBy varchar(200))";
            DbOperations.setDataOrDelete(billTable, "billTable Table has been successfully created");
            
               DbOperations.setDataOrDelete(billTable, "Bill Tables has been successfully created");
           //DbOperations.setDataOrDelete(userTable, "User Tables has been successfully created");
           //DbOperations.setDataOrDelete(adminDetails, "Admin details succesfully added");
          
           //DbOperations.setDataOrDelete(categoryTable, "Category Table Craeted Successfully ");
         //   DbOperations.setDataOrDelete(productTable, "Product Table Craeted Successfully ");
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(null, e);
        }
    }
}
